
from django.shortcuts import get_object_or_404, render, redirect

from django.contrib.auth.decorators import login_required

from django.http import JsonResponse


def check_login_status(request):
    return JsonResponse({'is_logged_in': request.user.is_authenticated})

@login_required

def check_user_type(request):
    if hasattr(request.user, 'payscanuser'):
        if hasattr(request.user.payscanuser, 'business'):
            return JsonResponse({'is_business_user': True})
        elif hasattr(request.user.payscanuser, 'agent'):
            return JsonResponse({'is_agent_user': True})
    return JsonResponse({'is_business_user': False, 'is_agent_user': False})

@login_required
def scanner(request):
    return render(request,'payscan/scanner.html')

def launch(request):      
    return render(request, 'payscan/index.html')

def appLaunch(request):      
    return render(request, 'payscan/usercheck.html')

def home(request):
    return render(request,'payscan/home.html')

