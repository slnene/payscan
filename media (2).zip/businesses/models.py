from django.db import models
from users.models import PayscanUser
from agents.models import Agent


class Business(models.Model):
    owner = models.ForeignKey(PayscanUser, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    balance = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    agent = models.ForeignKey(Agent, on_delete=models.SET_NULL, null=True, blank=True)
    qr_code = models.ImageField(upload_to='static/img/qrcodes/', blank=True, null=True)
    fcm_token = models.CharField(max_length=255, blank=True,default='n/a',null=True)
    def __str__(self):
        return f'{self.name} {self.owner} {self.balance}'
    
    def transaction_count(self):
        return self.transactions.count()
