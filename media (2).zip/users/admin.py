from django.contrib import admin
from .models import PayscanUser
# Register your models here.

admin.site.register(PayscanUser)
