from decimal import Decimal
from django.contrib.auth import authenticate, login ,logout
from django.contrib.auth.models import User
from django.shortcuts import get_object_or_404, render, redirect

from users.models import PayscanUser
from businesses.models import Business
from agents.models import Agent
from payscan.models import Transaction




from django.contrib.auth.decorators import login_required
from .forms import RegisterForm,DepositForm,WithdrawForm,PaymentForm

from django.http import HttpResponse
from django.http import JsonResponse
import requests
from django.conf import settings
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages

import os
from django.core.files import File
from django.conf import settings
import qrcode
from qrcode.image.styledpil import StyledPilImage
from qrcode.image.styles.moduledrawers import RoundedModuleDrawer
from qrcode.image.styles.colormasks import SolidFillColorMask
from qrcode.image.styles.colormasks import RadialGradiantColorMask
from qrcode.image.styles.colormasks import SquareGradiantColorMask
from qrcode.image.styles.colormasks import HorizontalGradiantColorMask
from qrcode.image.styles.colormasks import VerticalGradiantColorMask
from qrcode.image.styles.colormasks import ImageColorMask
from PIL import Image
import os
from django.core.files import File
from django.conf import settings
import qrcode
from qrcode.image.styledpil import StyledPilImage
from qrcode.image.styles.moduledrawers import RoundedModuleDrawer
from qrcode.image.styles.colormasks import SolidFillColorMask
from PIL import Image
from PIL import Image, ImageDraw, ImageFont
from PIL import Image, ImageDraw, ImageFont




def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            username = form.cleaned_data['username']
            first_name = form.cleaned_data['first_name']
            last_name = form.cleaned_data['last_name']
            password = form.cleaned_data['password1']
                            
            user = User.objects.create_user(email=email, username=username, first_name=first_name, last_name=last_name, password=password)          
            PayscanUser.objects.create(user=user)
            
            messages.success(request, 'Registration successful! Please log in.')
            return redirect('login')     
    else:
        form = RegisterForm()            
    return render(request, 'users/register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('/afterlogin')  # Redirect to a success page.
        else:
            return render(request, 'users/login.html', {'error': 'Invalid Phone number or password'})
    else:
        return render(request, 'users/login.html')
    
def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def dashboard(request):
    
    try:
        payscan_user = PayscanUser.objects.get(user=request.user)
        
        transactions = Transaction.objects.filter(payer=payscan_user).order_by('-timestamp')
    
        return render(request, 'users/dashboard.html', {'balance': payscan_user.balance ,'transactions': transactions})

    except PayscanUser.DoesNotExist:
        return render(request, 'users/login.html')
        pass
    
@login_required
def transaction_history(request):
    payscan_user = PayscanUser.objects.get(user=request.user)
    transactions = Transaction.objects.filter(user=payscan_user).order_by('-timestamp')
    return render(request, 'payscan/dashboard.html', {'transactions': transactions})

@login_required
def deposit(request):
    payscan_user = PayscanUser.objects.filter(user=request.user).first()
    if payscan_user is None:
        return render(request, 'payscan/deposit.html', {'form': DepositForm(), 'error': 'User does not exist'})

    if request.method == 'POST':
        form = DepositForm(request.POST)
        if form.is_valid():
            amount = form.cleaned_data['amount']
            payscan_user.balance += amount
            payscan_user.save()
            Transaction.objects.create(payer=payscan_user, amount=amount, transaction_type='deposit')
            return redirect('/afterlogin')
    else:
        form = DepositForm()
    return render(request, 'payscan/deposit.html', {'form': form})

@login_required
def withdraw(request,business_id):
    payscan_user = PayscanUser.objects.get(user=request.user)
    if request.method == 'POST':
        form = WithdrawForm(request.POST, balance=payscan_user.balance)
        if form.is_valid():
            amount = form.cleaned_data['amount']
            if payscan_user.balance >= amount:
                payscan_user.balance -= amount
                payscan_user.save()
                Transaction.objects.create(payer=payscan_user, amount=amount, transaction_type='withdraw')
                return redirect('/afterlogin')
    else:
        form = WithdrawForm(balance=payscan_user.balance)
    return render(request, 'payscan/withdraw.html', {'form': form})


def choose_wallet(request, business_id):
    business = get_object_or_404(Business, id=business_id)
    return render(request, 'users/choose_wallet.html', {'business': business})

def payment_momo(request, business_id):
    business = get_object_or_404(Business, id=business_id)
    return render(request, 'users/payment_momo.html', {'business': business})



@login_required
def payment(request, business_id):
    business = get_object_or_404(Business, id=business_id)
    payscan_user = PayscanUser.objects.get(user=request.user)
    if request.method == 'POST':
        form = PaymentForm(request.POST, balance=payscan_user.balance)
        if form.is_valid():
            amount = form.cleaned_data['amount']
            if payscan_user.balance >= amount:
                if amount < Decimal('20.00'):
                    commission_amount = Decimal('0.10')
                elif Decimal('20.00') <= amount < Decimal('50.00'):
                    commission_amount = Decimal('0.20')
                elif Decimal('50.00') <= amount < Decimal('100.00'):
                    commission_amount = Decimal('0.30')
                elif Decimal('100.00') <= amount < Decimal('200.00'):
                    commission_amount = Decimal('0.50')
                elif Decimal('200.00') <= amount < Decimal('500.00'):
                    commission_amount = Decimal('0.70')
                elif Decimal('500.00') <= amount:
                    commission_amount = Decimal('02.00')



                agent = business.agent

                payscan_user.balance -= amount
                payscan_user.save()

                business.balance += (amount)
                business.save()

                if agent:
                    agent.balance += commission_amount
                    agent.save()
                    
                if business:
                    transaction = Transaction.objects.create(
                        payer=payscan_user,
                        business=business,  # Ensure this field is set
                        amount=amount,
                        transaction_type='payment',
                        agent=agent,
                        commission=commission_amount
                    )
                    return redirect('payment_success', transaction_id=transaction.id)
                else:
                    # Handle the case where the business object is None
                    messages.error(request, "Business not found.")
                    return redirect('payment_error')

                
    else:
        form = PaymentForm(balance=payscan_user.balance)
    return render(request, 'users/payment.html', {'form': form, 'business': business})


@login_required
def payment_success(request, transaction_id):
    transaction = Transaction.objects.get(id=transaction_id)
    return render(request, 'payscan/payment_success.html', {'transaction': transaction})
