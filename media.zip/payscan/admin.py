from .models import PayscanUser,Transaction,Business,Agent

from django.contrib import admin

admin.site.register(PayscanUser),
admin.site.register(Business),
admin.site.register(Transaction),
admin.site.register(Agent),
