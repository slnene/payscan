from decimal import Decimal
from django.contrib.auth import authenticate, login ,logout
from django.contrib.auth.models import User
from django.shortcuts import get_object_or_404, render, redirect
import numpy as np
from .models import PayscanUser, Transaction, Business, Agent
from django.contrib.auth.decorators import login_required
from .forms import BusinessRegistrationForm_2, RegisterForm,DepositForm,WithdrawForm,PaymentForm,BusinessRegistrationForm
from .forms import BusinessLoginForm,BusinessPaymentForm,BusinessWithdrawForm,AgentRegisterForm,AgentLoginForm,AgentBusinessRegistrationForm

from django.http import HttpResponse
from django.http import JsonResponse
import requests
from django.conf import settings
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages

import os
from django.core.files import File
from django.conf import settings
import qrcode
from qrcode.image.styledpil import StyledPilImage
from qrcode.image.styles.moduledrawers import RoundedModuleDrawer
from qrcode.image.styles.colormasks import SolidFillColorMask
from qrcode.image.styles.colormasks import RadialGradiantColorMask
from qrcode.image.styles.colormasks import SquareGradiantColorMask
from qrcode.image.styles.colormasks import HorizontalGradiantColorMask
from qrcode.image.styles.colormasks import VerticalGradiantColorMask
from qrcode.image.styles.colormasks import ImageColorMask
from PIL import Image
import os
from django.core.files import File
from django.conf import settings
import qrcode
from qrcode.image.styledpil import StyledPilImage
from qrcode.image.styles.moduledrawers import RoundedModuleDrawer
from qrcode.image.styles.colormasks import SolidFillColorMask
from PIL import Image
from PIL import Image, ImageDraw, ImageFont
from PIL import Image, ImageDraw, ImageFont



def check_login_status(request):
    return JsonResponse({'is_logged_in': request.user.is_authenticated})

@login_required

def check_user_type(request):
    if hasattr(request.user, 'payscanuser'):
        if hasattr(request.user.payscanuser, 'business'):
            return JsonResponse({'is_business_user': True})
        elif hasattr(request.user.payscanuser, 'agent'):
            return JsonResponse({'is_agent_user': True})
    return JsonResponse({'is_business_user': False, 'is_agent_user': False})

@login_required
def scanner(request):
    return render(request,'payscan/scanner.html')

def launch(request):      
    return render(request, 'payscan/index.html')

def appLaunch(request):      
    return render(request, 'payscan/usercheck.html')

def home(request):
    return render(request,'payscan/home.html')

def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            username = form.cleaned_data['username']
            first_name = form.cleaned_data['first_name']
            last_name = form.cleaned_data['last_name']
            password = form.cleaned_data['password1']
                            
            user = User.objects.create_user(email=email, username=username, first_name=first_name, last_name=last_name, password=password)          
            PayscanUser.objects.create(user=user)
            
            messages.success(request, 'Registration successful! Please log in.')
            return redirect('login')     
    else:
        form = RegisterForm()            
    return render(request, 'payscan/register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('/afterlogin')  # Redirect to a success page.
        else:
            return render(request, 'payscan/login.html', {'error': 'Invalid Phone number or password'})
    else:
        return render(request, 'payscan/login.html')
    
def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def dashboard(request):
    
    try:
        payscan_user = PayscanUser.objects.get(user=request.user)
        
        transactions = Transaction.objects.filter(payer=payscan_user).order_by('-timestamp')
    
        return render(request, 'payscan/dashboard.html', {'balance': payscan_user.balance ,'transactions': transactions})

    except PayscanUser.DoesNotExist:
        return render(request, 'payscan/login.html')
        pass
    
@login_required
def transaction_history(request):
    payscan_user = PayscanUser.objects.get(user=request.user)
    transactions = Transaction.objects.filter(user=payscan_user).order_by('-timestamp')
    return render(request, 'payscan/dashboard.html', {'transactions': transactions})

@login_required
def deposit(request):
    payscan_user = PayscanUser.objects.filter(user=request.user).first()
    if payscan_user is None:
        return render(request, 'payscan/deposit.html', {'form': DepositForm(), 'error': 'User does not exist'})

    if request.method == 'POST':
        form = DepositForm(request.POST)
        if form.is_valid():
            amount = form.cleaned_data['amount']
            payscan_user.balance += amount
            payscan_user.save()
            Transaction.objects.create(payer=payscan_user, amount=amount, transaction_type='deposit')
            return redirect('/afterlogin')
    else:
        form = DepositForm()
    return render(request, 'payscan/deposit.html', {'form': form})

@login_required
def withdraw(request,business_id):
    payscan_user = PayscanUser.objects.get(user=request.user)
    if request.method == 'POST':
        form = WithdrawForm(request.POST, balance=payscan_user.balance)
        if form.is_valid():
            amount = form.cleaned_data['amount']
            if payscan_user.balance >= amount:
                payscan_user.balance -= amount
                payscan_user.save()
                Transaction.objects.create(payer=payscan_user, amount=amount, transaction_type='withdraw')
                return redirect('/afterlogin')
    else:
        form = WithdrawForm(balance=payscan_user.balance)
    return render(request, 'payscan/withdraw.html', {'form': form})

@login_required
def payment(request, business_id):
    business = get_object_or_404(Business, id=business_id)
    payscan_user = PayscanUser.objects.get(user=request.user)
    if request.method == 'POST':
        form = PaymentForm(request.POST, balance=payscan_user.balance)
        if form.is_valid():
            amount = form.cleaned_data['amount']
            if payscan_user.balance >= amount:
                if amount < Decimal('20.00'):
                    commission_amount = Decimal('0.10')
                elif Decimal('20.00') <= amount < Decimal('50.00'):
                    commission_amount = Decimal('0.20')
                elif Decimal('50.00') <= amount < Decimal('100.00'):
                    commission_amount = Decimal('0.30')
                elif Decimal('100.00') <= amount < Decimal('200.00'):
                    commission_amount = Decimal('0.50')
                elif Decimal('200.00') <= amount < Decimal('500.00'):
                    commission_amount = Decimal('0.70')
                elif Decimal('500.00') <= amount:
                    commission_amount = Decimal('02.00')



                agent = business.agent

                payscan_user.balance -= amount
                payscan_user.save()

                business.balance += (amount)
                business.save()

                if agent:
                    agent.balance += commission_amount
                    agent.save()
                    
                if business:
                    transaction = Transaction.objects.create(
                        payer=payscan_user,
                        business=business,  # Ensure this field is set
                        amount=amount,
                        transaction_type='payment',
                        agent=agent,
                        commission=commission_amount
                    )
                    return redirect('payment_success', transaction_id=transaction.id)
                else:
                    # Handle the case where the business object is None
                    messages.error(request, "Business not found.")
                    return redirect('payment_error')

                
    else:
        form = PaymentForm(balance=payscan_user.balance)
    return render(request, 'payscan/payment.html', {'form': form, 'business': business})


@login_required
def payment_success(request, transaction_id):
    transaction = Transaction.objects.get(id=transaction_id)
    return render(request, 'payscan/payment_success.html', {'transaction': transaction})

#####Business Suite###

def hex_to_rgb(hex_color):
    hex_color = hex_color.lstrip('#')
    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))

def register_business(request):
    if request.method == 'POST':
        form = BusinessRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            business_name = form.cleaned_data.get('business_name')
            payscan_user = PayscanUser.objects.create(user=user)
            business = Business.objects.create(owner=payscan_user, name=business_name)
            
            # Generate QR code
            qr_code_url = f"{settings.SITE_URL}/payment/{business.id}/"
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_H,
                box_size=10,
                border=4,
            )
            qr.add_data(qr_code_url)
            qr.make(fit=True)

            # Convert hex color to RGB
            background_color = hex_to_rgb("#e9d8d8")
            foreground_color = hex_to_rgb("#4d1616")

            # Customize the QR code
            qr_img = qr.make_image(
                image_factory=StyledPilImage,
                module_drawer=RoundedModuleDrawer(),
                color_mask=SolidFillColorMask(back_color=background_color, front_color=foreground_color)
            )

            # Add logo to the QR code
            logo_path = os.path.join(settings.BASE_DIR, 'payscan', 'static', 'img', 'payscan-navlogo.png')
            if os.path.exists(logo_path):
                logo = Image.open(logo_path)
                basewidth = 250
                wpercent = (basewidth / float(logo.size[0]))
                hsize = int((float(logo.size[1]) * float(wpercent)))
                logo = logo.resize((basewidth, hsize), Image.LANCZOS)
                pos = ((qr_img.size[0] - logo.size[0]) // 2, (qr_img.size[1] - logo.size[1]) // 2)
                qr_img.paste(logo, pos, mask=logo)

            # Add business name at the top left corner of the QR code image
            font_path = os.path.join(settings.BASE_DIR, 'payscan', 'static', 'fonts', 'arial.ttf')  # Ensure you have the font file
            font = ImageFont.truetype(font_path, 20)
            draw = ImageDraw.Draw(qr_img)
            text_position = (10, 10)  # Top left corner with some padding
            draw.text(text_position, business.name, font=font, fill=(0, 0, 0))

            # Save the QR code
            qr_code_path = os.path.join(settings.BASE_DIR, 'payscan', 'static', 'img','qrcodes' f'business_{business.name}_PHONE-{business.owner.user.username}_ID-{business.id}.png')
            os.makedirs(os.path.dirname(qr_code_path), exist_ok=True)
            qr_img.save(qr_code_path)
            
            # Save QR code to the business model (assuming you have a field for it)
            with open(qr_code_path, "rb") as qr_file:
                business.qr_code.save(f"business_{business.name}_{business.owner.user.username}_{business.id}.png", File(qr_file))
            
            messages.success(request, 'Business Registration successful! Please log in.')
            return redirect('login_business')
    else:
        form = BusinessRegistrationForm()
    return render(request, 'payscan/register_business.html', {'form': form})

@login_required
def register_business_2(request):
    if request.method == 'POST':
        form = BusinessRegistrationForm_2(request.POST)
        if form.is_valid():
            business_name = form.cleaned_data.get('business_name')
            payscan_user = PayscanUser.objects.get(user=request.user)
            business = Business.objects.create(owner=payscan_user, name=business_name)

                        
            # Generate QR code
            qr_code_url = f"{settings.SITE_URL}/payment/{business.id}/"
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_H,
                box_size=10,
                border=4,
            )
            qr.add_data(qr_code_url)
            qr.make(fit=True)

            # Convert hex color to RGB
            background_color = hex_to_rgb("#e9d8d8")
            foreground_color = hex_to_rgb("#4d1616")

            # Customize the QR code
            qr_img = qr.make_image(
                image_factory=StyledPilImage,
                module_drawer=RoundedModuleDrawer(),
                color_mask=SolidFillColorMask(back_color=background_color, front_color=foreground_color)
            )

            # Add logo to the QR code
            logo_path = os.path.join(settings.BASE_DIR, 'payscan', 'static', 'img', 'payscan-navlogo.png')
            if os.path.exists(logo_path):
                logo = Image.open(logo_path)
                basewidth = 250
                wpercent = (basewidth / float(logo.size[0]))
                hsize = int((float(logo.size[1]) * float(wpercent)))
                logo = logo.resize((basewidth, hsize), Image.LANCZOS)
                pos = ((qr_img.size[0] - logo.size[0]) // 2, (qr_img.size[1] - logo.size[1]) // 2)
                qr_img.paste(logo, pos, mask=logo)

            # Add business name at the top left corner of the QR code image
            font_path = os.path.join(settings.BASE_DIR, 'payscan', 'static', 'fonts', 'arial.ttf')  # Ensure you have the font file
            font = ImageFont.truetype(font_path, 20)
            draw = ImageDraw.Draw(qr_img)
            text_position = (10, 10)  # Top left corner with some padding
            draw.text(text_position, business.name, font=font, fill=(0, 0, 0))

            # Save the QR code
            qr_code_path = os.path.join(settings.BASE_DIR, 'payscan', 'static', 'img','qrcodes' f'business_{business.name}_PHONE-{business.owner.user.username}_ID-{business.id}.png')
            os.makedirs(os.path.dirname(qr_code_path), exist_ok=True)
            qr_img.save(qr_code_path)
            
            # Save QR code to the business model (assuming you have a field for it)
            with open(qr_code_path, "rb") as qr_file:
                business.qr_code.save(f"business_{business.name}_{business.owner.user.username}_{business.id}.png", File(qr_file))
            
            
            messages.success(request, 'Business registration successful! you were redirected to business dashboard.')
            return redirect('afterlogin_business')
    else:
        form = BusinessRegistrationForm_2()
    return render(request, 'payscan/register_business_2.html', {'form': form})

def login_business(request):
    if request.method == 'POST':
        form = BusinessLoginForm(data=request.POST)
        if form.is_valid():
            login(request, form.get_user())
            return redirect('afterlogin_business')
        else:
            return render(request, 'payscan/login_business.html', {'error': 'Invalid Phone number or password'})
    else:
        form = BusinessLoginForm()
    return render(request, 'payscan/login_business.html', {'form': form})

@login_required
def business_dashboard(request):
    try:
        payscan_user = PayscanUser.objects.get(user=request.user)
        business = Business.objects.get(owner=payscan_user)
        transactions = Transaction.objects.filter(payee=business).order_by('-timestamp')
        
        # Get the QR code URL
        qr_code_url = business.qr_code.url if business.qr_code else None

        return render(request, 'payscan/business_dashboard.html', {
            'business': business,
            'transactions': transactions,
            'qr_code_url': qr_code_url,
        })
        
    except PayscanUser.DoesNotExist:
        messages.error(request, "Payscan user not found.")
        return redirect('login_business')
    except Business.DoesNotExist:
        messages.error(request, "Business not found.")
        return redirect('register_business')

@login_required
def business_payment(request, business_id):
    business = Business.objects.get(owner__user=request.user)
    payee = get_object_or_404(Business, id=business_id)
    if request.method == 'POST':
        form = BusinessPaymentForm(request.POST, balance=business.balance)
        if form.is_valid():
            amount = form.cleaned_data['amount']
            if business.balance >= amount:
                commission_amount = 1
                agent = business.agent
                
                business.balance -= amount
                business.save()
                
                payee.balance += (amount - commission_amount)
                payee.save()
                
                if agent:
                    agent.user.balance += commission_amount
                    agent.user.save()
                
                transaction=Transaction.objects.create(payer=business.owner, 
                                                       payee=payee, 
                                                       amount=amount, 
                                                       transaction_type='payment',
                                                       agent=agent,
                                                       )
                return redirect('payment_success', transaction_id=transaction.id)
    else:
        form = BusinessPaymentForm(balance=business.balance)
    return render(request, 'payscan/business_payment.html', {'form': form, 'payee': payee})

@login_required
def business_withdraw(request):
    business = Business.objects.get(owner__user=request.user)
    if request.method == 'POST':
        form = BusinessWithdrawForm(request.POST, balance=business.balance)
        if form.is_valid():
            amount = form.cleaned_data['amount']
            if business.balance >= amount:
                business.balance -= amount
                business.save()
                Transaction.objects.create(payer=business.owner, amount=amount, transaction_type='withdraw')
                return redirect('afterlogin_business')
    else:
        form = BusinessWithdrawForm(balance=business.balance)
    return render(request, 'payscan/business_withdraw.html', {'form': form})


#####Agent Suite###

def register_agent(request):
    if request.method == 'POST':
        form = AgentRegisterForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            username = form.cleaned_data['username']
            first_name = form.cleaned_data['first_name']
            last_name = form.cleaned_data['last_name']
            password = form.cleaned_data['password1']
                            
            user = User.objects.create_user(email=email, username=username, first_name=first_name, last_name=last_name, password=password)          
            payscan_user = PayscanUser.objects.create(user=user)
            
            Agent.objects.create(agentuser=payscan_user)

            messages.success(request, 'Registration successful! Please log in.')
            return redirect('login_agent')
        else:
            print("Form is not valid:", form.errors)  # Debug statement
    else:
        form = AgentRegisterForm()
    return render(request, 'payscan/register_agent.html', {'form': form})


def register_agent_2(request):
    if request.method == 'POST':
        form = AgentRegisterForm(request.POST)
        if form.is_valid():
            
            payscan_user=PayscanUser.objects.create(user=request.user)
            Agent.objects.create(agentuser=payscan_user)

            return redirect('login_agent')     
    else:
            # Handle the case where the passwords do not match
        form = AgentRegisterForm()            
    return render(request, 'payscan/register_agent.html', {'form': form})


def login_agent(request):
    if request.method == 'POST':
        form = AgentLoginForm(data=request.POST)
        if form.is_valid():
            login(request, form.get_user())
            return redirect('afterlogin_agent')
        else:
            return render(request, 'payscan/login_agent.html', {'error': 'Invalid Phone number or password'})
    else:
        form = AgentLoginForm()
    return render(request, 'payscan/login_agent.html', {'form': form})

@login_required
def agent_dashboard(request):
    payscan_user = get_object_or_404(PayscanUser, user=request.user)
    agent = get_object_or_404(Agent, agentuser=payscan_user)
    transactions = Transaction.objects.filter(agent=agent).order_by('-timestamp')
    businesses = Business.objects.filter(agent=agent)

    # Calculate total earned commission (both paid and unpaid)
    total_earned_commission = sum(transaction.commission for transaction in transactions)

    # Get the business ID from the request (e.g., from a form or URL parameter)
    business_id = request.GET.get('business_id')

    # Filter transactions by the logged-in agent and the specified business ID
    filtered_transactions = Transaction.objects.filter(agent=agent, business_id=business_id)

    # Count the number of filtered transactions
    transaction_count = filtered_transactions.count()

    return render(request, 'payscan/agent_dashboard.html', {
        'agent': agent,
        'transactions': transactions,
        'total_earned_commission': total_earned_commission,
        'businesses': businesses,
        'transaction_count': transaction_count
    })

@login_required
def agent_register_business(request):
    if request.method == 'POST':
        form = AgentBusinessRegistrationForm(request.POST)
        if form.is_valid():
            business_name = form.cleaned_data['business_name']
            username = form.cleaned_data['username']
            owner_email = form.cleaned_data['owner_email']
            owner_first_name = form.cleaned_data['owner_first_name']
            owner_last_name = form.cleaned_data['owner_last_name']
            password = form.cleaned_data['password1']

        
            # Create a new user for the business owner
            owner_user = User.objects.create_user(email=owner_email, username=username, first_name=owner_first_name, last_name=owner_last_name, password=password)
            owner_payscan_user = PayscanUser.objects.create(user=owner_user)
            
            # Get the agent
            agent = Agent.objects.get(agentuser__user=request.user)
            
            # Create the business
            business = Business.objects.create(owner=owner_payscan_user, name=business_name, agent=agent)
        

                        
            # Generate QR code
            qr_code_url = f"{settings.SITE_URL}/payment/{business.id}/"
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_H,
                box_size=10,
                border=4,
            )
            qr.add_data(qr_code_url)
            qr.make(fit=True)

            # Convert hex color to RGB
            background_color = hex_to_rgb("#e9d8d8")
            foreground_color = hex_to_rgb("#4d1616")

            # Customize the QR code
            qr_img = qr.make_image(
                image_factory=StyledPilImage,
                module_drawer=RoundedModuleDrawer(),
                color_mask=SolidFillColorMask(back_color=background_color, front_color=foreground_color)
            )

            # Add logo to the QR code
            logo_path = os.path.join(settings.BASE_DIR, 'payscan', 'static', 'img', 'payscan-navlogo.png')
            if os.path.exists(logo_path):
                logo = Image.open(logo_path)
                basewidth = 250
                wpercent = (basewidth / float(logo.size[0]))
                hsize = int((float(logo.size[1]) * float(wpercent)))
                logo = logo.resize((basewidth, hsize), Image.LANCZOS)
                pos = ((qr_img.size[0] - logo.size[0]) // 2, (qr_img.size[1] - logo.size[1]) // 2)
                qr_img.paste(logo, pos, mask=logo)

            # Add business name at the top left corner of the QR code image
            font_path = os.path.join(settings.BASE_DIR, 'payscan', 'static', 'fonts', 'arial.ttf')  # Ensure you have the font file
            font = ImageFont.truetype(font_path, 20)
            draw = ImageDraw.Draw(qr_img)
            text_position = (10, 10)  # Top left corner with some padding
            draw.text(text_position, business.name, font=font, fill=(0, 0, 0))

            # Save the QR code
            qr_code_path = os.path.join(settings.BASE_DIR, 'payscan', 'static', 'img','qrcodes' f'business_{business.name}_PHONE-{business.owner.user.username}_ID-{business.id}.png')
            os.makedirs(os.path.dirname(qr_code_path), exist_ok=True)
            qr_img.save(qr_code_path)
            
            # Save QR code to the business model (assuming you have a field for it)
            with open(qr_code_path, "rb") as qr_file:
                business.qr_code.save(f"business_{business.name}_{business.owner.user.username}_{business.id}.png", File(qr_file))
            
            
            
            messages.success(request, 'Business registered successfully')
            return redirect('afterlogin_agent')
        else:
            print("Form is not valid:", form.errors)  # Debug statement
    else:
        form = AgentBusinessRegistrationForm()
    return render(request, 'payscan/agent_register_business.html', {'form': form})



