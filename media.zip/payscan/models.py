from django.contrib.auth.models import User
from django.db import models


class PayscanUser(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    balance = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)

    def __str__(self):
        return f'{self.user}'

class Business(models.Model):
    owner = models.ForeignKey(PayscanUser, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    balance = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    agent = models.ForeignKey('Agent', on_delete=models.SET_NULL, null=True, blank=True)
    qr_code = models.ImageField(upload_to='static/img/qrcodes/', blank=True, null=True)

    def __str__(self):
        return f'{self.name} {self.owner} {self.balance}'
    
    def transaction_count(self):
        return self.transactions.count()


class Agent(models.Model):
    agentuser = models.OneToOneField(PayscanUser, on_delete=models.CASCADE)
    balance = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    
    def __str__(self):
        return f'{self.agentuser}'

class Transaction(models.Model):
    payer = models.ForeignKey(PayscanUser, on_delete=models.CASCADE, related_name='payer')
    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name='transactions')
    payee = models.ForeignKey(Business, on_delete=models.CASCADE, related_name='payee', null=True, blank=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    timestamp = models.DateTimeField(auto_now_add=True)
    transaction_type = models.CharField(max_length=20)
    agent = models.ForeignKey('Agent', on_delete=models.CASCADE, null=True, blank=True)
    commission = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f'{self.payer} - {self.payee} - {self.amount} - {self.timestamp} - {self.transaction_type}'
